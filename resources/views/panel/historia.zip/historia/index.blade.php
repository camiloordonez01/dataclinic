@extends('layouts.app')

@section('content')
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                @if (session('success'))
                    <div class="card bg-success">
                        <div class="card-header">
                            <h3 class="card-title">Proceso exitoso:</h3>

                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i></button>
                            </div>
                        </div>
                        <div class="card-body">
                            {{session('success')}}
                        </div>
                    </div>
                @endif
                <div class="card">
                    <!-- /.card-header -->
                    <div class="card-body">
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>N°</th>
                                    <th>Cedula</th>
                                    <th>Nombres</th>
                                    <th>Apellidos</th>
                                    <th>Fecha</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($historias as $historia)
                                <tr>
                                    <td>{{$historia->id}}</td>
                                    <td>{{$historia->documento}}</td>
                                    <td>{{$historia->nombres}}</td>
                                    <td>{{$historia->apellidos}}</td>
                                    <td>{{$historia->fecha}}</td>
                                    <td>
                                        @if($historia->estado == 0)
                                        <small class="badge badge-info">Abierto</small>
                                        @else
                                        <small class="badge badge-success">Cerrado</small>
                                        @endif
                                    </td>
                                    <td>
                                        
                                        @can('historia.show')
                                        <a class="btn btn-success btn-sm" href="{{URL::action('HistoriaController@show',$historia->id)}}">
                                            <i class="fas fa-eye">
                                            </i>
                                            Ver
                                        </a>
                                        @endcan
                                        @if($historia->estado == 0)
                                        @can('historia.edit')
                                        <a class="btn btn-info btn-sm" href="{{URL::action('HistoriaController@edit',$historia->id)}}">
                                            <i class="fas fa-pencil-alt">
                                            </i>
                                            Terminar
                                        </a>
                                        @endcan
                                        @can('historia.close')
                                        <a class="btn btn-primary btn-sm" href="#" data-toggle="modal" data-target="#modal-warning-{{$historia->id}}">
                                            <i class="fas fa-times-circle"></i>
                                            Cerrar
                                        </a>
                                        <div class="modal fade show" id="modal-warning-{{$historia->id}}" aria-modal="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content modal-principal">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Cerrar historia</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    {{Form::Open(array('action'=>array('HistoriaController@close',$historia->id),'method'=>'delete'))}}
                                                        <div class="modal-body">
                                                            <p class="text-center">Confirme si desea cerrar la historia {{$historia->id}}</p>
                                                        </div>
                                                        <div class="modal-footer justify-content-between">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-primary btn-principal">Confirmar</button>
                                                        </div>
                                                    {{Form::Close()}}
                                                </div>
                                                <!-- /.modal-content -->
                                            </div>
                                            <!-- /.modal-dialog -->
                                        </div>
                                        @endcan
                                        @endif
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>N°</th>
                                    <th>Cedula</th>
                                    <th>Nombres</th>
                                    <th>Apellidos</th>
                                    <th>Fecha</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
            </div>
        </div>
    </div>
</section>
<script>
  $(function () {
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
      "order": [[0, 'des']],
    });
  });
</script>
@endsection