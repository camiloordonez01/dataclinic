@extends('layouts.app')

@section('content')

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card" id="welcome">
                <div class="card-body">
                    <h1 class="text-center display-1">Bienvenido(a)</h1>
                </div>
            </div>
        </div>         
    </div>
</div>
@endsection